module.exports = {
  PORT: 3000,
  security: {
    SESSION_SECRET: "YOUR-SESSION-SECRET-STRING",
    PASSWORD_SALT: "YOUR-PASSWORD-SALT",
    PASSWORD_STRETCH: 3
  },
  search: {
    MAX_ITEMS_PER_PAGE: 5
  }
};