SELECT
  count(*) as `count`,
  sum(score) as `sum`
FROM
  t_review
WHERE
  shop_id = ?
