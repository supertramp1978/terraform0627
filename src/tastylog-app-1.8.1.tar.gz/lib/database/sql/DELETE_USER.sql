DELETE FROM
  t_user
WHERE
  email = ?
