INSERT INTO
  t_user (`id`, `email`, `password`, `created_datetime`)
VALUES
  (NULL, ?, ?, now())