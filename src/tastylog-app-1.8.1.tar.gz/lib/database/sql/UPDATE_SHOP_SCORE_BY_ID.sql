UPDATE
  t_shop
SET
  score = ?
WHERE
  id = ?
