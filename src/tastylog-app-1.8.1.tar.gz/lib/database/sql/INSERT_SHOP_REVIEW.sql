INSERT INTO
  t_review (`shop_id`, `user_id`, `score`, `visit`, `post`, `description`)
VALUES
  (?, ?, ?, ?, now(), ?)