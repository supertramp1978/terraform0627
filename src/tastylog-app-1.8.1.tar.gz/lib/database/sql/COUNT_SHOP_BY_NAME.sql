SELECT
  count(*) as count
FROM
  t_shop
WHERE name LIKE ?
