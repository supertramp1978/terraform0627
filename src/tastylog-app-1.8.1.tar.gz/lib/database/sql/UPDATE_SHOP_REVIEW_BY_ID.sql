UPDATE
  t_review
SET
  `score` = ?,
  `visit` = ?,
  `post` = ?,
  `description` = ?
WHERE
  id = ?
