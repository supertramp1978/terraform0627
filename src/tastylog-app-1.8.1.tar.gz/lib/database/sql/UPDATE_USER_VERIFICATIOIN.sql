UPDATE
  t_user
SET
  verified_datetime = now()
WHERE
  email = ?
