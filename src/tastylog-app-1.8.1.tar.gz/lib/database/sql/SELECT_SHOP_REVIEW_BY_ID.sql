SELECT
  review.id,
  review.shop_id,
  t_shop.name as shop_name,
  review.user_id,
  review.score,
  review.visit,
  review.post,
  review.description
FROM
  (
    SELECT
      *
    FROM
      t_review
    WHERE
      id = ?
  ) as review
LEFT JOIN t_shop ON review.shop_id = t_shop.id
