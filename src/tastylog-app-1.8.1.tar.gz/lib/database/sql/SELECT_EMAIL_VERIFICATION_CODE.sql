SELECT
  verification_code
FROM
  t_email_verification
WHERE
  email = ?