SELECT
  id,
  name,
  score
FROM
  t_shop
WHERE
  id IN (?)