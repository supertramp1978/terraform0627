DELETE FROM
  t_review
WHERE
  id = ?
