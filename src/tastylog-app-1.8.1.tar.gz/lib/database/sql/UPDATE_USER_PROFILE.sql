UPDATE
  t_user
SET
  name = ?,
  description = ?
WHERE
  email = ?
