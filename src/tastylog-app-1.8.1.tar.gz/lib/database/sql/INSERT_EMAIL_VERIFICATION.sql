INSERT INTO
  t_email_verification (`email`, `verification_code`, `created_datetime`)
VALUES
  (?, ?, now())