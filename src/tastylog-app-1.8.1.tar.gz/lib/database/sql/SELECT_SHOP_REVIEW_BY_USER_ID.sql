SELECT
  review.id,
  t_shop.id as shop_id,
  t_shop.name as shop_name,
  review.score,
  review.visit,
  review.post,
  review.description
FROM
(
  SELECT
    *
  FROM
    t_review
  WHERE
    user_id = ?
) as review
LEFT JOIN
  t_shop
ON review.shop_id = t_shop.id
