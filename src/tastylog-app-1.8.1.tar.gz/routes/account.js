var { authenticate, authorize } = require("../lib/security/accountcontrol.js");
var router = require("express").Router();

router.get("/", authorize("normal"), (request, response) => {
  response.render("./account/index.ejs");
});

router.get("/login", (req, res) => {
  res.render("./account/login.ejs", { message: req.flash("message") });
});

router.post("/login", authenticate());

router.post("/logout", (req, res) => {
  req.logout();
  res.redirect("/account/login");
});

router.use("/regist", require("./account.regist.js"));

router.use("/seeyou", (request, response) => {
  response.render("./account/seeyou.ejs");
});

router.use("/settings", authorize("normal"), require("./account.settings.js"));
router.use("/review", authorize("normal"), require("./account.review.js"));

module.exports = router;