var router = require("express").Router();
var { MySqlClient, SQL } = require("../lib/database/client.js");
var Recommend = require("../lib/recommend/recommend.js");

router.get("/:id", (req, res) => {
  var id = req.params.id;

  Promise.all([
    MySqlClient.executeQuery(
      SQL["SELECT_SHOP_DETAIL_BY_ID"],
      [id]
    ),
    MySqlClient.executeQuery(
      SQL["SELECT_SHOP_REVIEW_BY_SHOP_ID"],
      [id]
    ),
    Recommend.get().then((recommends) => {
      return MySqlClient.executeQuery(
        SQL["SELECT_RECOMMEND_SHOP_LIST"],
        [recommends]
      );
    })
  ]).then((results) => {
    var data = results[0][0];
    data.reviews = (results[1] || []);
    data.recommends = (results[2] || []);
    res.render("./shop/index.ejs", data);
  }).catch((error) => {
    res.end(error);
  });
});

module.exports = router;