var { round } = require("../lib/math/math.js");
var router = require("express").Router();
var { MySqlClient, SQL } = require("../lib/database/client.js");

var validateReviewData = function (request) {
  var body = request.body;
  var isValid = true, error = {};

  if (!body.user_id && !body.user_name) {
    isValid = false;
    error.user = "ユーザー名が指定されていません。";
  }

  if (!body.visit || (body.visit && (new RegExp("\\d{4}/\\d{1,2}/\\d{1,2}")).test(body.visit) === false)) {
    isValid = false;
    error.visit = "日付の形式が不正です。";
  }

  if (isValid) {
    return undefined;
  }
  return error;
};

var createReviewData = function (request) {
  var body = request.body;
  return {
    id: request.params.id,
    user_id: body.user_id,
    user_name: body.user_name,
    score: parseFloat(body.score),
    visit: ((body.visit && (new RegExp("\\d{4}/\\d{1,2}/\\d{1,2}")).test(body.visit)) ? new Date(body.visit) : null),
    post: new Date(),
    description: body.description
  };
};

router.get("/", async (request, response) => {
  var userId = request.user.id;

  var reviews = await MySqlClient.executeQuery(
    SQL["SELECT_SHOP_REVIEW_BY_USER_ID"],
    [userId]
  );

  response.render("./account/review/index.ejs", { reviews });
});

router.get("/regist", async (request, response, next) => {
  var shop_id = request.query.shop;

  try {
    var results = await MySqlClient.executeQuery(
      SQL["SELECT_SHOP_BASIC_BY_ID"],
      [shop_id]
    );

    var shop = results[0] || {};
    var shopId = shop.id;
    var shopName = shop.name;
    var review = {
      user_id: request.user.id,
      user_name: request.user.name
    };

    response.render("./account/review/regist-form.ejs", { shopId, shopName, review });
  } catch (error) {
    next(error);
  }
});

router.post("/regist/input", (request, response) => {
  var review = createReviewData(request);
  var shopId = request.body.shopId;
  var shopName = request.body.shopName;
  response.render("./account/review/regist-form.ejs", { shopId, shopName, review });
});

router.post("/regist/confirm", (request, response) => {
  var error = validateReviewData(request);
  var review = createReviewData(request);
  var shopId = request.body.shopId;
  var shopName = request.body.shopName;

  if (error) {
    response.render("./account/review/regist-form.ejs", { error, shopId, shopName, review });
    return;
  }

  response.render("./account/review/regist-confirm.ejs", { shopId, shopName, review });
});

router.post("/regist/execute", async (request, response, next) => {
  var error = validateReviewData(request);
  var review = createReviewData(request);
  var shopId = request.body.shopId;
  var shopName = request.body.shopName;
  var userId = request.body.user_id;

  if (error) {
    response.render("./account/review/regist-form.ejs", { error, shopId, shopName, review });
    return;
  }

  var transaction;
  try {
    transaction = await MySqlClient.beginTransaction();
    var results = await transaction.executeQuery(
      SQL["SELECT_SHOP_SCORE_BY_SHOP_ID"],
      [shopId]
    );
    await transaction.executeQuery(
      SQL["UPDATE_SHOP_SCORE_BY_ID"],
      [round((results[0].sum + review.score) / (results[0].count + 1), 2), shopId]
    );
    await transaction.executeQuery(
      SQL["INSERT_SHOP_REVIEW"],
      [shopId, userId, review.score, review.visit, review.description]);
    await transaction.commit();

    response.redirect(`/account/review/regist/complete?shop=${shopId}`);
  } catch (error) {
    await transaction.rollback();
    next(error);
  }
});

router.get("/regist/complete", (request, response) => {
  response.render("./account/review/regist-complete.ejs", { shopId: request.query.shop });
});

router.get("/:id/edit", async (request, response, next) => {
  var reviewId = request.params.id;

  try {
    var results = await MySqlClient.executeQuery(
      SQL["SELECT_SHOP_REVIEW_BY_ID"],
      [reviewId]
    );
    var row = results[0];

    var shopId = row.shop_id;
    var shopName = row.shop_name;
    var review = {
      id: row.id,
      user_id: request.user.id,
      user_name: request.user.name,
      score: row.score,
      visit: row.visit,
      post: row.post,
      description: row.description
    };

    response.render("./account/review/edit-form.ejs", { shopId, shopName, review });
  } catch (error) {
    next(error);
  }
});

router.post("/:id/edit/input", (request, response) => {
  var shopId = request.body.shopId;
  var shopName = request.body.shopName;
  var review = createReviewData(request);
  var error = validateReviewData(request);
  response.render("./account/review/edit-form.ejs", { error, shopId, shopName, review });
});

router.post("/:id/edit/confirm", (request, response) => {
  var shopId = request.body.shopId;
  var shopName = request.body.shopName;
  var review = createReviewData(request);
  var error = validateReviewData(request);
  if (error) {
    response.render("./account/review/edit-form.ejs", { error, shopId, shopName, review });
    return;
  }
  response.render("./account/review/edit-confirm.ejs", { shopId, shopName, review });
});

router.post("/:id/edit/execute", async (request, response, next) => {
  var review = createReviewData(request);
  var error = validateReviewData(request);
  var shopId = request.body.shopId;
  var shopName = request.body.shopName;

  if (error) {
    response.render("./account/review/edit-form.ejs", { error, shopId, shopName, review });
    return;
  }

  var transaction;
  try {
    transaction = await MySqlClient.beginTransaction();
    var results = await transaction.executeQuery(
      SQL["SELECT_SHOP_SCORE_BY_SHOP_ID"],
      [shopId]
    );
    await transaction.executeQuery(
      SQL["UPDATE_SHOP_SCORE_BY_ID"],
      [round((results[0].sum + review.score) / (results[0].count + 1), 2), shopId]
    );
    await transaction.executeQuery(
      SQL["UPDATE_SHOP_REVIEW_BY_ID"],
      [review.score, review.visit, review.post, review.description, review.id]);
    await transaction.commit();

    response.redirect(`/account/review/${review.id}/edit/complete?shop=${shopId}`);
  } catch (error) {
    await transaction.rollback();
    next(error);
  }
});

router.get("/:id/edit/complete", (request, response) => {
  var shopId = request.query.shop;
  response.render("./account/review/edit-complete.ejs", { shopId });
});

router.get("/:id/delete", async (request, response, next) => {
  var reviewId = request.params.id;

  try {
    var results = await MySqlClient.executeQuery(
      SQL["SELECT_SHOP_REVIEW_BY_ID"],
      [reviewId]
    );
    var row = results[0];

    var shopId = row.shop_id;
    var shopName = row.shop_name;
    var review = {
      id: row.id,
      user_id: request.user.id,
      user_name: request.user.name,
      score: row.score,
      visit: row.visit,
      post: row.post,
      description: row.description
    };

    response.render("./account/review/delete-confirm.ejs", { shopId, shopName, review });
  } catch (error) {
    next(error);
  }
});

router.post("/:id/delete/execute", async (request, response, next) => {
  var shopId = request.body.shopId;
  var reviewScore = parseFloat(request.body.score);
  var reviewId = request.params.id;

  var transaction, score;
  try {
    transaction = await MySqlClient.beginTransaction();

    var results = await transaction.executeQuery(
      SQL["SELECT_SHOP_SCORE_BY_SHOP_ID"],
      [shopId]
    );

    if (results[0].count > 1) {
      score = round((results[0].sum - reviewScore) / (results[0].count - 1), 2);
    } else {
      score = null;
    }

    await transaction.executeQuery(
      SQL["UPDATE_SHOP_SCORE_BY_ID"],
      [score, shopId]
    );

    await MySqlClient.executeQuery(
      SQL["DELETE_SHOP_REVIEW_BY_ID"],
      [reviewId]
    );

    await transaction.commit();

    response.redirect(`/account/review/regist/complete?shop=${shopId}`);
  } catch (error) {
    await transaction.rollback();
    next(error);
  }
});

router.get("/:id/delete/complete", (request, response) => {
  var shopId = request.query.shop;
  response.render("./account/review/delete-complete.ejs", { shopId });
});

module.exports = router;