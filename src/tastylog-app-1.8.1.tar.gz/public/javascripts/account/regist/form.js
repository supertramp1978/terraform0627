var chkIsAgreedTerms_click = function (event) {
  $("#submit").prop("disabled", !$(this).prop("checked"));
};

var document_onready = function () {
  $("#isAgreedTerms").on("click", chkIsAgreedTerms_click);
};

$(document).ready(document_onready);