#!/bin/bash

mysql --defaults-extra-file=../dbaccess.cnf < ./alter_user.sql

